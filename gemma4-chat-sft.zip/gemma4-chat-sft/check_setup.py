#!/usr/bin/env python3
"""
Pre-flight checks before committing hours of laptop time to a run.

Cheap (tokenizer only, ~seconds):
  * renders one training example exactly the way mlx-lm's chat dataset does and
    verifies the prompt render is a strict prefix of the full render (so the
    prompt mask lands on the right tokens), with thinking disabled
  * flags any thinking markers in the rendered text
  * exact token lengths for every example -> max_seq_length and tokens/epoch

With --load-model (loads the weights, ~16 GB for bf16):
  * applies the LoRA config and counts trainable parameters; a zero here means
    the lora_parameters.keys do not match this model's module names
  * prints weight memory so you know the floor before activations

    python check_setup.py                          # uses configs/lora_e4b.yaml and its data dir
    python check_setup.py --load-model
    python check_setup.py --model models/gemma-4-e4b-it-8bit
"""
from __future__ import annotations

import argparse
import json
import re
import statistics
import sys
import time
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import THINK_MARKERS, disable_thinking, read_jsonl  # noqa: E402


def pct(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(round(q * (len(xs) - 1))))]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/lora_e4b.yaml")
    p.add_argument("--data", default=None)
    p.add_argument("--model", default=None)
    p.add_argument("--load-model", action="store_true")
    p.add_argument("--show", type=int, default=1, help="print this many rendered examples")
    args = p.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    model_id = args.model or cfg["model"]
    data = Path(args.data or cfg["data"])
    max_seq = int(cfg.get("max_seq_length", 2048))
    bs = int(cfg.get("batch_size", 4))

    import mlx.core as mx
    import mlx_lm
    from mlx_lm.utils import load_tokenizer

    print(f"mlx {mx.__version__}   mlx-lm {mlx_lm.__version__}")
    print(f"model: {model_id}")
    print(f"data:  {data}")

    t0 = time.time()
    tok = disable_thinking(load_tokenizer(model_id))
    print(f"tokenizer loaded in {time.time() - t0:.1f}s   eos ids: {sorted(tok.eos_token_ids)}   "
          f"has_chat_template={tok.has_chat_template}")

    # ---------------- template / mask check -----------------------------------------
    rows = {name: read_jsonl(data / f"{name}.jsonl") for name in ("train", "valid", "test")
            if (data / f"{name}.jsonl").exists()}
    if "train" not in rows:
        sys.exit(f"{data}/train.jsonl missing - run prepare_data.py")
    print({k: len(v) for k, v in rows.items()})

    problems = 0
    for ex in rows["train"][: args.show]:
        msgs = ex["messages"]
        full = tok.apply_chat_template(msgs, return_dict=False)
        prompt = tok.apply_chat_template(msgs[:-1], add_generation_prompt=True, return_dict=False)
        ok = full[: len(prompt)] == prompt
        full_text = tok.apply_chat_template(msgs, tokenize=False)  # pure template output, no detokenizer artefacts
        print("\n----- rendered training example (loss is computed on the part after the marker) -----")
        print(tok.decode(prompt) + "\n<<<<< LOSS STARTS HERE >>>>>\n" + tok.decode(full[len(prompt):]))
        print("-----")
        print(f"prompt tokens={len(prompt)}  completion tokens={len(full) - len(prompt)}  total={len(full)}")
        if not ok:
            problems += 1
            print("PROBLEM: the generation prompt is NOT a prefix of the full render, so mask_prompt would "
                  "mis-align. Usual cause: the template adds an empty-thought prefill to the generation prompt "
                  "but not to rendered assistant turns. Fix: re-run prepare_data.py with "
                  "--assistant-prefix '<|channel>thought\\n<channel|>' (or whatever the prefill is) and re-check.")
        else:
            print("ok: generation prompt is a prefix of the full render (prompt mask aligns)")
        # an immediately-closed empty thought channel is the documented "thinking off" prefill and is fine;
        # a <|think|> flag or a thought channel with content is not
        stripped = re.sub(r"<\|channel>thought\s*<channel\|>", "", full_text)
        found = [m for m in THINK_MARKERS if m in stripped]
        if found:
            problems += 1
            print(f"PROBLEM: thinking markers present in the render: {found}")
        else:
            print("ok: no thinking flag / thought content in the render"
                  + (" (empty-thought prefill present, that is fine)" if stripped != full_text else ""))
        last = full[len(prompt):]
        if last and last[-1] in tok.eos_token_ids:
            print("ok: render ends with an end-of-turn token the generator stops on")
        else:
            tail = tok.decode(last[-3:]) if last else ""
            print(f"NOTE: final token {last[-1] if last else None} ({tail!r}) is not in eos_token_ids "
                  f"{sorted(tok.eos_token_ids)}; extract.py also cuts at '<turn|>' so this is usually fine")

    # ---------------- token length stats --------------------------------------------
    print("\n----- token lengths -----")
    t0 = time.time()
    totals, prompts, comps = [], [], []
    for name, rs in rows.items():
        for ex in rs:
            msgs = ex["messages"]
            full = tok.apply_chat_template(msgs, return_dict=False)
            prm = tok.apply_chat_template(msgs[:-1], add_generation_prompt=True, return_dict=False)
            totals.append(len(full)); prompts.append(len(prm)); comps.append(len(full) - len(prm))
    n = len(totals)
    over = sum(1 for t in totals if t > max_seq)
    print(f"{n} examples tokenized in {time.time() - t0:.1f}s")
    print(f"total      p50={pct(totals, .5)}  p95={pct(totals, .95)}  max={max(totals)}")
    print(f"prompt     p50={pct(prompts, .5)}  p95={pct(prompts, .95)}  max={max(prompts)}")
    print(f"completion p50={pct(comps, .5)}  p95={pct(comps, .95)}  max={max(comps)}   "
          f"(share of tokens trained on: {sum(comps) / sum(totals):.0%})")
    rec = ((max(totals) + 63) // 64) * 64
    if over:
        problems += 1
        print(f"PROBLEM: {over} examples exceed max_seq_length={max_seq} and would be truncated "
              f"(their JSON tail is lost). Set max_seq_length: {rec} in the config.")
    else:
        print(f"ok: all examples fit max_seq_length={max_seq} (max {max(totals)}; {rec} would be a tight setting)")
    train_tokens = sum(len(tok.apply_chat_template(ex["messages"], return_dict=False)) for ex in rows["train"])
    print(f"train tokens per epoch: ~{train_tokens:,}  (at 100 tok/s ≈ {train_tokens / 100 / 60:.0f} min/epoch, "
          f"at 300 tok/s ≈ {train_tokens / 300 / 60:.0f} min/epoch; SMOKE=1 ./train.sh measures your real rate)")
    if len(rows["train"]) < bs:
        problems += 1
        print(f"PROBLEM: train set smaller than batch_size={bs}")
    if "valid" in rows and len(rows["valid"]) < bs:
        problems += 1
        print(f"PROBLEM: valid set ({len(rows['valid'])}) smaller than batch_size={bs}; mlx-lm needs >= one batch")

    # ---------------- model / LoRA keys ---------------------------------------------
    if args.load_model:
        from mlx.utils import tree_flatten
        from mlx_lm import load
        from mlx_lm.tuner.utils import linear_to_lora_layers

        print("\n----- model -----")
        t0 = time.time()
        model, _ = load(model_id)
        params = tree_flatten(model.parameters())
        n_params = sum(v.size for _, v in params)
        n_bytes = sum(v.nbytes for _, v in params)
        print(f"loaded in {time.time() - t0:.0f}s: {n_params / 1e9:.2f}B params, {n_bytes / 2**30:.1f} GiB of weights, "
              f"{len(model.layers)} decoder blocks, active memory {mx.get_active_memory() / 2**30:.1f} GiB")
        model.freeze()
        num_layers = int(cfg.get("num_layers", 16))
        lp = cfg["lora_parameters"]
        linear_to_lora_layers(model, num_layers, lp, use_dora=(cfg.get("fine_tune_type") == "dora"))
        trainable = sum(v.size for _, v in tree_flatten(model.trainable_parameters()))
        print(f"LoRA: rank={lp['rank']} scale={lp['scale']} keys={lp.get('keys')} num_layers={num_layers}")
        print(f"trainable parameters: {trainable / 1e6:.1f}M ({trainable / n_params:.3%})")
        adapted = [k for k, m in model.layers[-1].named_modules() if hasattr(m, "lora_a")]
        if trainable == 0 or not adapted:
            problems += 1
            print("PROBLEM: no module matched lora_parameters.keys. Modules in a decoder block:")
            for k, m in model.layers[-1].named_modules():
                if type(m).__name__.endswith("Linear"):
                    print("   ", k, type(m).__name__)
        else:
            print(f"ok: adapters on {len(adapted)} modules in the last block ({adapted}); "
                  f"Gemma 4's KV-shared tail blocks have no k_proj/v_proj, earlier blocks get all 7")

    print("\n" + ("ALL CHECKS PASSED" if not problems else f"{problems} PROBLEM(S) FOUND - fix before training"))
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()

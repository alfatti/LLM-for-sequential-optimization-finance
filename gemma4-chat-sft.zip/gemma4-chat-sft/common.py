"""
Shared pieces for the Bloomberg-chat quote extractor SFT pipeline.

Everything that must be *identical* between data preparation, training,
evaluation and inference lives here:

  * the fixed key order of the output schema
  * the canonical (compact, deterministic) JSON serialization of a label list
  * the system prompt
  * parsing of model output back into a label list
  * value comparison and "literal grounding" checks used for metrics / QA

No MLX imports here, so this module also runs on Linux for unit tests.
"""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = 1

# One short sentence of instruction + the key list. Prompt tokens are masked
# out of the loss (mask_prompt=true), so a long prompt buys nothing during
# training and only costs forward/backward compute, and prefill at inference.
DEFAULT_SYSTEM_TEMPLATE = (
    "Extract every quote in the Bloomberg chat message as a JSON array. "
    "Each quote is an object with exactly these keys, in this order: {keys}. "
    "Copy values literally from the message; use null for anything not stated. "
    "Output only the JSON array."
)

_END_OF_TURN_MARKERS = ("<turn|>", "<end_of_turn>", "<eos>")
_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)
_NUM_RE = re.compile(r"\d+(?:[.,]\d+)*")


# --------------------------------------------------------------------------- #
# Loading records
# --------------------------------------------------------------------------- #
def load_records(path: str | Path) -> list[dict]:
    """Load labelled records from a JSON array, a dict wrapping a list, or JSONL."""
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            return obj
        if isinstance(obj, dict):
            # e.g. {"data": [...]} or {"records": [...]}
            lists = [v for v in obj.values() if isinstance(v, list)]
            if len(lists) == 1:
                return lists[0]
            if "raw_message" in obj:  # a single record
                return [obj]
        raise ValueError(f"Unrecognised JSON layout in {path}")
    except json.JSONDecodeError:
        records = []
        for ln, line in enumerate(text.splitlines(), 1):
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{ln}: bad JSONL line: {e}") from e
        return records


def read_jsonl(path: str | Path) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path: str | Path, rows: Iterable[dict]) -> int:
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            n += 1
    return n


# --------------------------------------------------------------------------- #
# Schema / canonical target
# --------------------------------------------------------------------------- #
def infer_keys(records: Iterable[dict]) -> list[str]:
    """Ordered union of label keys, in order of first appearance."""
    keys: list[str] = []
    seen: set[str] = set()
    for r in records:
        for lab in r.get("labels") or []:
            if not isinstance(lab, dict):
                continue
            for k in lab:
                if k not in seen:
                    seen.add(k)
                    keys.append(k)
    return keys


def normalize_value(v: Any, empty_as_null: bool = True) -> Any:
    """Light normalization of a label value: strip strings, map '' -> null.

    Deliberately does NOT coerce numeric strings to numbers: the type in the
    labels is the type the model is trained to emit.
    """
    if v is None:
        return None
    if isinstance(v, str):
        s = v.strip()
        if empty_as_null and (s == "" or s.lower() in {"null", "none"}):
            return None
        return s
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    return v


def canonical_labels(labels: list[dict] | None, keys: list[str]) -> list[dict]:
    """Reorder every label onto the fixed key list, filling missing keys with null."""
    out = []
    for lab in labels or []:
        if not isinstance(lab, dict):
            raise TypeError(f"label must be an object, got {type(lab).__name__}: {lab!r}")
        out.append({k: normalize_value(lab.get(k)) for k in keys})
    return out


def to_target_json(labels: list[dict], keys: list[str]) -> str:
    """Compact, deterministic JSON string the model is trained to emit."""
    return json.dumps(canonical_labels(labels, keys), ensure_ascii=False, separators=(",", ":"))


def build_system_prompt(keys: list[str], template: str = DEFAULT_SYSTEM_TEMPLATE) -> str:
    return template.format(keys=", ".join(keys))


def make_messages(system_prompt: str, raw_message: str, target_json: str | None = None) -> list[dict]:
    msgs = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": raw_message},
    ]
    if target_json is not None:
        msgs.append({"role": "assistant", "content": target_json})
    return msgs


def load_schema(path: str | Path) -> dict:
    with open(path, encoding="utf-8") as f:
        schema = json.load(f)
    for req in ("keys", "system_prompt"):
        if req not in schema:
            raise ValueError(f"{path} is missing '{req}'")
    return schema


# --------------------------------------------------------------------------- #
# Parsing model output
# --------------------------------------------------------------------------- #
def parse_output(text: str, lenient: bool = False) -> tuple[list[dict] | None, str | None]:
    """Parse the model's text into a list of label dicts.

    Returns (labels, error). Always tolerates a trailing end-of-turn marker,
    code fences and a bare object instead of a one-element array. In strict
    mode (default) the JSON must be the whole output; `lenient=True` salvages
    the first JSON value from surrounding text. Malformed JSON is never
    repaired: a parse failure is a model failure we want to measure, not hide.
    """
    if text is None:
        return None, "empty output"
    s = text
    for m in _END_OF_TURN_MARKERS:
        i = s.find(m)
        if i >= 0:
            s = s[:i]
    fence = _FENCE_RE.search(s)
    if fence:
        s = fence.group(1)
    s = s.strip()
    if not s:
        return None, "empty output"
    starts = [i for i in (s.find("["), s.find("{")) if i >= 0]
    if not starts:
        return None, "no JSON found"
    start = min(starts)
    if start != 0 and not lenient:
        return None, "text before JSON"
    try:
        obj, end = json.JSONDecoder().raw_decode(s[start:])
    except json.JSONDecodeError as e:
        return None, f"invalid JSON: {e.msg} at {e.pos}"
    if s[start + end:].strip() and not lenient:
        return None, "text after JSON"
    if isinstance(obj, dict):
        obj = [obj]
    if not isinstance(obj, list) or not all(isinstance(x, dict) for x in obj):
        return None, "JSON is not an array of objects"
    return obj, None


# --------------------------------------------------------------------------- #
# Comparison and grounding
# --------------------------------------------------------------------------- #
def _is_number(x: Any) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _coerce_numeric_string(x: Any) -> Any:
    if isinstance(x, str):
        t = x.strip().replace(",", "")
        try:
            return float(t) if ("." in t or "e" in t.lower()) else int(t)
        except ValueError:
            return x
    return x


def values_equal(gold: Any, pred: Any, lenient: bool = False) -> bool:
    """Strict by default: same type class (null / number / string) and same value."""
    gold, pred = normalize_value(gold), normalize_value(pred)
    if gold is None or pred is None:
        return gold is None and pred is None
    if lenient:
        gold, pred = _coerce_numeric_string(gold), _coerce_numeric_string(pred)
    if _is_number(gold) and _is_number(pred):
        return math.isclose(float(gold), float(pred), rel_tol=1e-9, abs_tol=1e-9)
    if isinstance(gold, str) and isinstance(pred, str):
        if lenient:
            return " ".join(gold.split()).casefold() == " ".join(pred.split()).casefold()
        return gold == pred
    return gold == pred


def literal_forms(v: Any) -> list[str]:
    """Candidate surface forms of a value, for checking it appears in the message."""
    if v is None:
        return []
    if isinstance(v, bool):
        return [str(v).lower()]
    if isinstance(v, int):
        return sorted({str(v), f"{v:,}", str(abs(v))}, key=len, reverse=True)
    if isinstance(v, float):
        forms = {repr(v), str(v), f"{v:.10g}"}
        if v.is_integer():
            forms.update({str(int(v)), f"{int(v):,}"})
        txt = f"{v:.10f}".rstrip("0").rstrip(".")
        forms.add(txt)
        forms.update({f.lstrip("-") for f in list(forms)})
        forms.update({f[1:] for f in list(forms) if f.startswith("0.")})  # ".5" for 0.5
        return sorted(forms, key=len, reverse=True)
    s = str(v).strip()
    return [s] if s else []


def is_grounded(v: Any, raw_message: str) -> bool:
    """True if some surface form of `v` occurs verbatim (case-insensitive) in the message."""
    if v is None:
        return True
    hay = raw_message.casefold()
    return any(f.casefold() in hay for f in literal_forms(v))


def template_signature(raw_message: str, labels: list[dict] | None) -> str:
    """Abstract a message into its 'template' by masking label values and numbers.

    Used for group-aware splitting so that paraphrase-free synthetic variants
    of the same template cannot leak from train into valid/test.
    """
    s = raw_message
    vals = []
    for lab in labels or []:
        for v in (lab or {}).values():
            if isinstance(v, str) and v.strip():
                vals.append(v.strip())
    for v in sorted(set(vals), key=len, reverse=True):
        s = re.sub(re.escape(v), " <V> ", s, flags=re.IGNORECASE)
    s = _NUM_RE.sub("#", s)
    s = re.sub(r"\s+", " ", s).strip().casefold()
    return s


def disable_thinking(tokenizer):
    """Force `enable_thinking=False` in every chat-template render.

    mlx-lm's TokenizerWrapper detects Gemma 4's thought-channel tokens and then
    defaults `enable_thinking=True` whenever the caller does not say otherwise,
    which is what its LoRA dataset loader does. For a literal extractor we want
    the plain (non-thinking) prompt format, identically at train and inference
    time, so train.py, check_setup.py, evaluate.py and extract.py all route the
    tokenizer through this. Works for the wrapper and for a bare HF tokenizer.
    """
    orig = tokenizer.apply_chat_template

    def apply_chat_template_no_think(*args, **kwargs):
        kwargs.setdefault("enable_thinking", False)
        return orig(*args, **kwargs)

    tokenizer.apply_chat_template = apply_chat_template_no_think
    return tokenizer


THINK_MARKERS = ("<|think|>", "<|channel>thought", "<think>")


def flatten_values(labels: list[dict] | None) -> list[tuple[int, str, Any]]:
    out = []
    for i, lab in enumerate(labels or []):
        for k, v in (lab or {}).items():
            out.append((i, k, v))
    return out

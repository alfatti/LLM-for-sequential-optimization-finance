#!/usr/bin/env bash
# Launch a LoRA run with mlx-lm.
#
#   ./train.sh                       # 2 epochs, bf16 base from configs/lora_e4b.yaml
#   EPOCHS=3 ./train.sh
#   MODEL=models/gemma-4-e4b-it-8bit ./train.sh        # QLoRA on a 24 GB Mac
#   NUM_LAYERS=21 BATCH=2 ./train.sh                   # lighter run
#   SMOKE=1 ./train.sh               # 8 iterations: proves the model loads, keys match, memory fits
#   RESUME=adapters/run-.../adapters.safetensors ./train.sh
#
# Environment knobs: CONFIG DATA EPOCHS BATCH MODEL NUM_LAYERS LR MAX_SEQ ADAPTER SMOKE RESUME
# Anything after the script name is passed straight to mlx_lm.lora (e.g. --report-to wandb).
set -euo pipefail
cd "$(dirname "$0")"

CONFIG=${CONFIG:-configs/lora_e4b.yaml}
DATA=${DATA:-data}
EPOCHS=${EPOCHS:-2}
STAMP=$(date +%Y%m%d-%H%M%S)
if [[ "${SMOKE:-0}" == "1" ]]; then
  ADAPTER=${ADAPTER:-adapters/smoke}
  rm -rf "$ADAPTER"
else
  ADAPTER=${ADAPTER:-adapters/run-$STAMP}
fi
mkdir -p "$ADAPTER"

args=(--config "$CONFIG" --data "$DATA" --epochs "$EPOCHS" --adapter-path "$ADAPTER" --out "$ADAPTER/config.resolved.yaml")
[[ -n "${BATCH:-}" ]]      && args+=(--batch-size "$BATCH")
[[ -n "${MODEL:-}" ]]      && args+=(--model "$MODEL")
[[ -n "${NUM_LAYERS:-}" ]] && args+=(--num-layers "$NUM_LAYERS")
[[ -n "${LR:-}" ]]         && args+=(--learning-rate "$LR")
[[ -n "${MAX_SEQ:-}" ]]    && args+=(--max-seq-length "$MAX_SEQ")
[[ "${SMOKE:-0}" == "1" ]] && args+=(--iters 8)

python resolve_config.py "${args[@]}" | tee "$ADAPTER/run_summary.json"

extra=()
[[ -n "${RESUME:-}" ]] && extra+=(--resume-adapter-file "$RESUME")

echo
echo "==> python train.py --config $ADAPTER/config.resolved.yaml ${extra[*]:-} $*"
echo "==> log: $ADAPTER/train.log"
# train.py == mlx_lm.lora with thinking disabled in the chat template (see common.disable_thinking).
# PYTHONUNBUFFERED so the log file fills in real time; `tee` keeps it on screen too.
# (the ${extra[@]+...} form keeps macOS's bash 3.2 happy with `set -u` and an empty array)
PYTHONUNBUFFERED=1 python train.py --config "$ADAPTER/config.resolved.yaml" ${extra[@]+"${extra[@]}"} "$@" 2>&1 | tee "$ADAPTER/train.log"

echo
echo "adapter: $ADAPTER/adapters.safetensors"
echo "next:    python evaluate.py --adapter-path $ADAPTER --out $ADAPTER/eval"

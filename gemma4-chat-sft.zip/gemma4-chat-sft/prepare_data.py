#!/usr/bin/env python3
"""
Turn the labelled chat sample into mlx-lm `chat` JSONL for SFT.

Input  : a JSON array / JSONL of records {"raw_message": str, "labels": [ {...}, ... ], "source": str}
Output : <out>/train.jsonl, valid.jsonl, test.jsonl   (mlx-lm chat format + metadata columns)
         <out>/schema.json                             (key order, system prompt, literal fields)
         <out>/stats.json                              (dataset statistics)
         <out>/label_qa.jsonl                          (suspicious labels to review)

Splitting is *group-aware* by default: records are grouped by an abstracted
template signature (label values and numbers masked out) so that near-identical
synthetic variants of the same template never straddle train and valid/test.
Splits are stratified by `source`.

Example
    python prepare_data.py --input labels.json --out data
    python prepare_data.py --input labels.json --out data --repeat-nonnull TRADE=3 --repeat-nonnull SIZE=2
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import random
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (  # noqa: E402
    SCHEMA_VERSION,
    build_system_prompt,
    canonical_labels,
    flatten_values,
    infer_keys,
    is_grounded,
    load_records,
    make_messages,
    template_signature,
    to_target_json,
    write_jsonl,
)


def pct(xs, q):
    if not xs:
        return 0
    xs = sorted(xs)
    k = min(len(xs) - 1, max(0, int(round(q * (len(xs) - 1)))))
    return xs[k]


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", required=True, help="labels JSON (array) or JSONL file")
    p.add_argument("--out", default="data", help="output directory")
    p.add_argument("--schema", default=None, help="optional JSON file with a list of keys fixing the output order")
    p.add_argument("--split-by", choices=["group", "random"], default="group")
    p.add_argument("--valid-frac", type=float, default=0.10)
    p.add_argument("--test-frac", type=float, default=0.10)
    p.add_argument("--min-groups", type=int, default=10,
                   help="per source, fall back to a random split if fewer template groups than this")
    p.add_argument("--seed", type=int, default=13)
    p.add_argument("--literal-threshold", type=float, default=0.95,
                   help="a field is 'literal' if at least this share of its non-null gold values appear verbatim in the message")
    p.add_argument("--repeat-nonnull", action="append", default=[], metavar="FIELD=K",
                   help="oversample train examples where FIELD is non-null K times (repeatable)")
    p.add_argument("--max-chars", type=int, default=4000, help="drop messages longer than this many characters")
    p.add_argument("--system-prompt-file", default=None, help="override the default system prompt text ({keys} placeholder allowed)")
    p.add_argument("--keep-empty-strings", action="store_true", help="do not map '' to null")
    p.add_argument("--assistant-prefix", default="",
                   help="text prepended to every assistant target, e.g. the empty-thought prefill "
                        "'<|channel>thought\\n<channel|>' if check_setup.py reports that the generation prompt "
                        "is not a prefix of the full render (backslash-n is unescaped)")
    return p.parse_args()


def main():
    args = parse_args()
    rng = random.Random(args.seed)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    raw_records = load_records(args.input)
    print(f"loaded {len(raw_records)} records from {args.input}")

    # ---- validate / normalise ------------------------------------------------
    records = []
    bad = collections.Counter()
    for i, r in enumerate(raw_records):
        msg = r.get("raw_message")
        labels = r.get("labels")
        if not isinstance(msg, str) or not msg.strip():
            bad["missing raw_message"] += 1
            continue
        if labels is None:
            labels = []
        if isinstance(labels, dict):
            labels = [labels]
        if not isinstance(labels, list) or not all(isinstance(x, dict) for x in labels):
            bad["labels not a list of objects"] += 1
            continue
        if len(msg) > args.max_chars:
            bad[f"longer than {args.max_chars} chars"] += 1
            continue
        records.append({
            "idx": i,
            "raw_message": msg.strip(),
            "labels": labels,
            "source": str(r.get("source") or "unknown"),
        })
    if bad:
        print("dropped:", dict(bad))

    # ---- schema -----------------------------------------------------------------
    if args.schema:
        keys = json.loads(Path(args.schema).read_text())
        if isinstance(keys, dict):
            keys = keys["keys"]
    else:
        keys = infer_keys(records)
    if not keys:
        sys.exit("no label keys found")
    print(f"schema keys ({len(keys)}): {keys}")

    for r in records:
        extra = sorted({k for lab in r["labels"] for k in lab if k not in keys})
        if extra:
            bad["labels with keys outside schema"] += 1
            if bad["labels with keys outside schema"] <= 5:
                print(f"  WARNING record {r['idx']} has keys outside schema (ignored): {extra}")
        r["labels"] = canonical_labels(r["labels"], keys)

    template = None
    if args.system_prompt_file:
        template = Path(args.system_prompt_file).read_text(encoding="utf-8").strip()
    system_prompt = build_system_prompt(keys, template) if template else build_system_prompt(keys)

    # ---- exact-duplicate handling ------------------------------------------------
    qa_rows = []
    by_text: dict[str, dict] = {}
    deduped = []
    n_dup = n_conflict = 0
    for r in records:
        key = " ".join(r["raw_message"].split()).casefold()
        if key in by_text:
            n_dup += 1
            first = by_text[key]
            if first["labels"] != r["labels"]:
                n_conflict += 1
                qa_rows.append({
                    "idx": r["idx"], "kind": "duplicate message, different labels",
                    "raw_message": r["raw_message"], "labels": r["labels"],
                    "conflicts_with_idx": first["idx"], "other_labels": first["labels"],
                })
            continue
        by_text[key] = r
        deduped.append(r)
    records = deduped
    print(f"exact duplicates removed: {n_dup} (of which {n_conflict} had conflicting labels -> label_qa.jsonl)")

    # ---- literal-grounding audit of the gold labels -------------------------------
    nonnull = collections.Counter()
    grounded = collections.Counter()
    for r in records:
        for _, k, v in flatten_values(r["labels"]):
            if v is None:
                continue
            nonnull[k] += 1
            if is_grounded(v, r["raw_message"]):
                grounded[k] += 1
    literal_rate = {k: (grounded[k] / nonnull[k] if nonnull[k] else None) for k in keys}
    literal_fields = [k for k in keys if nonnull[k] >= 20 and literal_rate[k] is not None
                      and literal_rate[k] >= args.literal_threshold]
    for r in records:
        for leg, k, v in flatten_values(r["labels"]):
            if v is not None and k in literal_fields and not is_grounded(v, r["raw_message"]):
                qa_rows.append({
                    "idx": r["idx"], "kind": "literal field value not found in message",
                    "field": k, "leg": leg, "value": v, "raw_message": r["raw_message"],
                })

    # ---- split --------------------------------------------------------------------
    for r in records:
        sig = template_signature(r["raw_message"], r["labels"])
        r["group"] = hashlib.sha1(f"{r['source']}|{sig}".encode()).hexdigest()[:12]

    split_of: dict[int, str] = {}
    by_source = collections.defaultdict(list)
    for r in records:
        by_source[r["source"]].append(r)

    for source, rs in sorted(by_source.items()):
        n = len(rs)
        n_test = int(round(args.test_frac * n))
        n_valid = int(round(args.valid_frac * n))
        groups = collections.defaultdict(list)
        for r in rs:
            groups[r["group"]].append(r)
        use_group = args.split_by == "group" and len(groups) >= args.min_groups
        if args.split_by == "group" and not use_group:
            print(f"  WARNING source={source!r}: only {len(groups)} template groups (<{args.min_groups}); "
                  f"using a random split for this source")
        if use_group:
            units = list(groups.values())
            rng.shuffle(units)
        else:
            units = [[r] for r in rs]
            rng.shuffle(units)
        filled = {"test": 0, "valid": 0}
        for unit in units:
            if filled["test"] < n_test:
                tgt = "test"
            elif filled["valid"] < n_valid:
                tgt = "valid"
            else:
                tgt = "train"
            for r in unit:
                split_of[r["idx"]] = tgt
            if tgt in filled:
                filled[tgt] += len(unit)
        print(f"  source={source!r}: n={n} groups={len(groups)} "
              f"split={'group' if use_group else 'random'} "
              f"train={n - filled['test'] - filled['valid']} valid={filled['valid']} test={filled['test']}")

    splits = {"train": [], "valid": [], "test": []}
    for r in records:
        splits[split_of[r["idx"]]].append(r)

    # ---- oversampling (train only) ---------------------------------------------
    repeat_spec = {}
    for spec in args.repeat_nonnull:
        f, k = spec.split("=")
        if f not in keys:
            sys.exit(f"--repeat-nonnull: unknown field {f!r}")
        repeat_spec[f] = int(k)
    if repeat_spec:
        extra = []
        for r in splits["train"]:
            k_max = max((k for f, k in repeat_spec.items()
                         if any(lab.get(f) is not None for lab in r["labels"])), default=1)
            extra.extend([r] * (k_max - 1))
        print(f"oversampling: +{len(extra)} train copies for {repeat_spec}")
        splits["train"].extend(extra)
    rng.shuffle(splits["train"])

    # ---- write ------------------------------------------------------------------
    assistant_prefix = args.assistant_prefix.encode().decode("unicode_escape") if args.assistant_prefix else ""

    def to_row(r):
        target = assistant_prefix + to_target_json(r["labels"], keys)
        return {
            "messages": make_messages(system_prompt, r["raw_message"], target),
            "raw_message": r["raw_message"],
            "labels": canonical_labels(r["labels"], keys),
            "source": r["source"],
            "group": r["group"],
            "idx": r["idx"],
        }

    counts = {}
    for name, rs in splits.items():
        if not rs:
            print(f"  NOTE: {name} split is empty; not writing {name}.jsonl")
            (out / f"{name}.jsonl").unlink(missing_ok=True)
            counts[name] = 0
            continue
        counts[name] = write_jsonl(out / f"{name}.jsonl", (to_row(r) for r in rs))
    n_qa = write_jsonl(out / "label_qa.jsonl", qa_rows)

    # ---- stats -----------------------------------------------------------------
    legs = collections.Counter(len(r["labels"]) for r in records)
    n_legs = sum(len(r["labels"]) for r in records)
    chars = [len(r["raw_message"]) for r in records]
    target_chars = [len(to_target_json(r["labels"], keys)) for r in records]
    # share of quote legs in which the field is non-null
    field_nonnull_rate = {k: (nonnull[k] / n_legs if n_legs else 0) for k in keys}
    stats = {
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "input": str(args.input),
        "n_input": len(raw_records),
        "n_after_dedup": len(records),
        "dropped": dict(bad),
        "exact_duplicates_removed": n_dup,
        "conflicting_duplicates": n_conflict,
        "splits": counts,
        "split_by": args.split_by,
        "seed": args.seed,
        "sources": dict(collections.Counter(r["source"] for r in records)),
        "legs_per_message": {str(k): v for k, v in sorted(legs.items())},
        "messages_with_no_quotes": legs.get(0, 0),
        "field_nonnull_rate": field_nonnull_rate,
        "field_literal_rate": literal_rate,
        "literal_fields": literal_fields,
        "label_qa_rows": n_qa,
        "message_chars": {"p50": pct(chars, .5), "p95": pct(chars, .95), "max": max(chars) if chars else 0},
        "target_chars": {"p50": pct(target_chars, .5), "p95": pct(target_chars, .95), "max": max(target_chars) if target_chars else 0},
        "approx_tokens_per_example_p95": int((len(system_prompt) + pct(chars, .95) + pct(target_chars, .95)) / 3.3) + 24,
        "repeat_nonnull": repeat_spec,
        "assistant_prefix": assistant_prefix,
    }
    (out / "stats.json").write_text(json.dumps(stats, indent=2))
    schema = {
        "version": SCHEMA_VERSION,
        "keys": keys,
        "system_prompt": system_prompt,
        "literal_fields": literal_fields,
        "field_nonnull_rate": field_nonnull_rate,
        "field_literal_rate": literal_rate,
        "assistant_prefix": assistant_prefix,
        "created": stats["created"],
    }
    (out / "schema.json").write_text(json.dumps(schema, indent=2, ensure_ascii=False))

    # ---- report -----------------------------------------------------------------
    print()
    print(f"splits: {counts}   (written to {out}/)")
    print(f"legs per message: {dict(sorted(legs.items()))}   messages with no quotes: {legs.get(0, 0)}   "
          f"total legs: {n_legs}")
    print(f"{'field':<18}{'non-null':>10}{'(n)':>7}{'literal':>10}")
    for k in keys:
        lr = literal_rate[k]
        tag = "   <- literal" if k in literal_fields else ("   (too few non-null to judge)" if 0 < nonnull[k] < 20 else "")
        print(f"{k:<18}{field_nonnull_rate[k]:>10.1%}{nonnull[k]:>7}{(f'{lr:.1%}' if lr is not None else '-'):>10}{tag}")
    print(f"message chars p50/p95/max: {stats['message_chars']}   "
          f"target chars p50/p95/max: {stats['target_chars']}")
    print(f"rough tokens per example (p95): ~{stats['approx_tokens_per_example_p95']}  "
          f"(run check_setup.py for exact token lengths)")
    if n_qa:
        print(f"\n{n_qa} suspicious label rows written to {out / 'label_qa.jsonl'} - worth a look before training")
    if legs.get(0, 0) == 0:
        print("\nNOTE: no messages with an empty label list. If the deployed extractor will see chatter "
              "lines with no quote, add some negatives so it learns to emit [].")


if __name__ == "__main__":
    main()

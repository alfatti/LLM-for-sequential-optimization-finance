#!/usr/bin/env python3
"""
Resolve a base LoRA YAML into a run-specific config.

Fills in iters from EPOCHS and the training-set size, the cosine schedule
length, eval/checkpoint cadence, and any overrides, then writes the result
so every run keeps an exact record of what it was trained with.

    python resolve_config.py --config configs/lora_e4b.yaml --data data --epochs 2 \
        --adapter-path adapters/run1 --out adapters/run1/config.resolved.yaml
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml


def count_lines(path: Path) -> int:
    with open(path, "rb") as f:
        return sum(1 for line in f if line.strip())


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--data", default=None)
    p.add_argument("--epochs", type=float, default=2.0)
    p.add_argument("--iters", type=int, default=None, help="override iters directly (e.g. smoke test)")
    p.add_argument("--batch-size", type=int, default=None)
    p.add_argument("--model", default=None)
    p.add_argument("--num-layers", type=int, default=None)
    p.add_argument("--learning-rate", type=float, default=None)
    p.add_argument("--max-seq-length", type=int, default=None)
    p.add_argument("--adapter-path", required=True)
    p.add_argument("--out", required=True)
    args = p.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    for k in ("data", "model", "batch_size", "num_layers", "learning_rate", "max_seq_length"):
        v = getattr(args, k)
        if v is not None:
            cfg[k] = v
    cfg["adapter_path"] = args.adapter_path

    data = Path(cfg["data"])
    train_file = data / "train.jsonl"
    if not train_file.exists():
        sys.exit(f"{train_file} not found - run prepare_data.py first")
    n_train = count_lines(train_file)
    bs = int(cfg["batch_size"])
    if n_train < bs:
        sys.exit(f"train set has {n_train} examples, fewer than batch_size={bs}")
    iters_per_epoch = n_train // bs  # mlx-lm drops the trailing partial batch

    if args.iters is not None:
        iters = args.iters
    else:
        iters = max(1, int(round(iters_per_epoch * args.epochs)))
    cfg["iters"] = iters

    lr = float(cfg["learning_rate"])
    warmup = min(100, max(5, int(round(0.05 * iters)))) if iters > 20 else 0
    sched = cfg.get("lr_schedule")
    if sched:
        sched["warmup"] = warmup
        sched["arguments"] = [lr, max(1, iters - warmup), lr / 10]
        cfg["lr_schedule"] = sched

    cfg["steps_per_eval"] = max(10, min(iters, iters_per_epoch // 4 or 10))
    cfg["save_every"] = max(10, min(iters, iters_per_epoch))
    cfg["steps_per_report"] = max(1, min(cfg.get("steps_per_report", 10), iters))

    # yaml floats like 1e-5 must be written in a form every loader reads as float
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(cfg, sort_keys=False, default_flow_style=None))

    summary = {
        "model": cfg["model"],
        "n_train": n_train,
        "batch_size": bs,
        "grad_accumulation_steps": cfg.get("grad_accumulation_steps", 1),
        "iters_per_epoch": iters_per_epoch,
        "epochs": round(iters / iters_per_epoch, 2),
        "iters": iters,
        "optimizer_updates": iters // int(cfg.get("grad_accumulation_steps", 1) or 1),
        "warmup": warmup,
        "peak_lr": lr,
        "steps_per_eval": cfg["steps_per_eval"],
        "save_every": cfg["save_every"],
        "num_layers": cfg["num_layers"],
        "lora": cfg.get("lora_parameters"),
        "resolved_config": str(out),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

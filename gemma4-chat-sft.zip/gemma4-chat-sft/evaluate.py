#!/usr/bin/env python3
"""
Field-level evaluation of the extractor on a held-out split.

    # adapter on the base model
    python evaluate.py --adapter-path adapters/run-20261029-0130 --out adapters/run-20261029-0130/eval

    # the untuned model with the same prompt (baseline)
    python evaluate.py --out runs/baseline

    # a fused model
    python evaluate.py --model models/bbchat-e4b --out runs/fused

    # re-score an existing predictions file without a model (runs anywhere)
    python evaluate.py --score-only runs/baseline/predictions.jsonl

Reports, overall and per `source`:
  json_valid      share of outputs from which an array of objects could be parsed
  clean           share of outputs that were *only* the JSON array (no leading/trailing text)
  exact_match     whole message correct (every leg, every field, strict types)
  exact_lenient   same, after case-folding strings and coercing numeric strings
  leg_count       number of quotes correct
  per field       accuracy on aligned legs, recall on gold non-null, precision on
                  predicted non-null, and the three error modes (missed / spurious / wrong value)
  grounding       share of predicted non-null values in literal fields that occur verbatim
                  in the message (a hallucination detector for a literal extractor)
"""
from __future__ import annotations

import argparse
import collections
import json
import sys
import time
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import is_grounded, load_schema, read_jsonl, values_equal, write_jsonl  # noqa: E402


# --------------------------------------------------------------------------- #
# Scoring (pure python)
# --------------------------------------------------------------------------- #
def score_row(gold: list[dict], pred: list[dict] | None, keys: list[str], literal_fields: list[str],
              raw_message: str, salvaged: bool = False) -> dict:
    """Per-message scoring. Legs are aligned by position (order of appearance)."""
    out = {"json_valid": pred is not None, "clean": pred is not None and not salvaged, "leg_count_ok": False,
           "exact": False, "exact_lenient": False, "fields": {}, "grounded": 0, "grounded_total": 0}
    if pred is None:
        out["fields"] = {k: {"correct": 0, "total": max(len(gold), 1), "gold_nonnull": sum(g.get(k) is not None for g in gold),
                             "pred_nonnull": 0, "tp": 0, "missed": sum(g.get(k) is not None for g in gold),
                             "spurious": 0, "wrong": 0} for k in keys}
        return out
    out["leg_count_ok"] = len(pred) == len(gold)
    all_ok = all_ok_len = True
    for k in keys:
        f = {"correct": 0, "total": max(len(gold), len(pred)), "gold_nonnull": 0, "pred_nonnull": 0,
             "tp": 0, "missed": 0, "spurious": 0, "wrong": 0}
        for i in range(max(len(gold), len(pred))):
            g = gold[i].get(k) if i < len(gold) else None
            p = pred[i].get(k) if i < len(pred) else None
            g_has, p_has = g is not None, p is not None
            f["gold_nonnull"] += g_has
            f["pred_nonnull"] += p_has
            if values_equal(g, p):
                f["correct"] += 1
                f["tp"] += g_has
            else:
                all_ok = False
                if g_has and not p_has:
                    f["missed"] += 1
                elif p_has and not g_has:
                    f["spurious"] += 1
                else:
                    f["wrong"] += 1
            if not values_equal(g, p, lenient=True):
                all_ok_len = False
        out["fields"][k] = f
    if not gold and not pred:
        all_ok = all_ok_len = True
    out["exact"] = bool(all_ok and len(gold) == len(pred))
    out["exact_lenient"] = bool(all_ok_len and len(gold) == len(pred))
    for q in pred:
        for k in literal_fields:
            v = q.get(k)
            if v is not None:
                out["grounded_total"] += 1
                out["grounded"] += is_grounded(v, raw_message)
    return out


def aggregate(scored: list[dict], keys: list[str]) -> dict:
    n = len(scored)
    if n == 0:
        return {"n": 0}
    agg = {
        "n": n,
        "json_valid": sum(s["json_valid"] for s in scored) / n,
        "clean": sum(s["clean"] for s in scored) / n,
        "exact_match": sum(s["exact"] for s in scored) / n,
        "exact_lenient": sum(s["exact_lenient"] for s in scored) / n,
        "leg_count": sum(s["leg_count_ok"] for s in scored) / n,
    }
    gt = sum(s["grounded_total"] for s in scored)
    agg["grounding"] = (sum(s["grounded"] for s in scored) / gt) if gt else None
    fields = {}
    tot_correct = tot_total = 0
    for k in keys:
        c = collections.Counter()
        for s in scored:
            for m, v in s["fields"].get(k, {}).items():
                c[m] += v
        tot_correct += c["correct"]; tot_total += c["total"]
        fields[k] = {
            "accuracy": c["correct"] / c["total"] if c["total"] else None,
            "recall": c["tp"] / c["gold_nonnull"] if c["gold_nonnull"] else None,
            "precision": c["tp"] / c["pred_nonnull"] if c["pred_nonnull"] else None,
            "gold_nonnull": c["gold_nonnull"], "missed": c["missed"], "spurious": c["spurious"], "wrong": c["wrong"],
        }
    agg["field_accuracy_micro"] = tot_correct / tot_total if tot_total else None
    agg["fields"] = fields
    return agg


def score_predictions(rows: list[dict], keys: list[str], literal_fields: list[str]) -> tuple[dict, list[dict]]:
    scored_rows = []
    for r in rows:
        salvaged = any(str(w).startswith("salvaged") for w in (r.get("warnings") or []))
        s = score_row(r["labels"], r.get("quotes"), keys, literal_fields, r["raw_message"], salvaged=salvaged)
        s["source"] = r.get("source", "unknown")
        scored_rows.append(s)
    report = {"overall": aggregate(scored_rows, keys), "by_source": {}}
    for src in sorted({s["source"] for s in scored_rows}):
        report["by_source"][src] = aggregate([s for s in scored_rows if s["source"] == src], keys)
    return report, scored_rows


def fmt(x, w=7):
    return f"{x:>{w}.1%}" if isinstance(x, float) else f"{'-':>{w}}"


def print_report(report: dict, keys: list[str]) -> None:
    o = report["overall"]
    print(f"\n{'':<18}{'n':>6}{'json':>8}{'clean':>8}{'exact':>8}{'lenient':>8}{'legs':>8}{'fields':>8}{'ground':>8}")
    rows = [("overall", o)] + sorted(report["by_source"].items())
    for name, a in rows:
        print(f"{name:<18}{a['n']:>6}{fmt(a['json_valid'])}{fmt(a['clean'])}{fmt(a['exact_match'])}{fmt(a['exact_lenient'])}"
              f"{fmt(a['leg_count'])}{fmt(a['field_accuracy_micro'])}{fmt(a['grounding'])}")
    print(f"\n{'field':<18}{'acc':>7}{'recall':>8}{'prec':>7}{'gold≠null':>11}{'missed':>8}{'spurious':>10}{'wrong':>7}")
    for k in keys:
        f = o["fields"][k]
        print(f"{k:<18}{fmt(f['accuracy'])}{fmt(f['recall'], 8)}{fmt(f['precision'])}{f['gold_nonnull']:>11}"
              f"{f['missed']:>8}{f['spurious']:>10}{f['wrong']:>7}")


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #
def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", default="configs/lora_e4b.yaml", help="used for the default model/data")
    p.add_argument("--model", default=None, help="base or fused model (default: config model)")
    p.add_argument("--adapter-path", default=None)
    p.add_argument("--data", default=None, help="jsonl to evaluate (default: <config data>/test.jsonl)")
    p.add_argument("--schema", default=None, help="default: <data dir>/schema.json")
    p.add_argument("--out", default=None, help="output directory (default: <adapter>/eval or runs/eval-<time>)")
    p.add_argument("--limit", type=int, default=0, help="evaluate only the first N rows")
    p.add_argument("--max-tokens", type=int, default=384)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--score-only", default=None, help="predictions.jsonl to re-score (no model needed)")
    args = p.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text()) if Path(args.config).exists() else {}
    data_dir = Path(cfg.get("data", "data"))
    data_file = Path(args.data) if args.data else data_dir / "test.jsonl"
    schema_path = Path(args.schema) if args.schema else data_file.parent / "schema.json"
    schema = load_schema(schema_path)
    keys, literal_fields = schema["keys"], schema.get("literal_fields", [])

    if args.score_only:
        rows = read_jsonl(args.score_only)
        report, scored = score_predictions(rows, keys, literal_fields)
        print_report(report, keys)
        out = Path(args.out) if args.out else Path(args.score_only).parent
        out.mkdir(parents=True, exist_ok=True)
        (out / "metrics.json").write_text(json.dumps(report, indent=2))
        print(f"\nmetrics -> {out / 'metrics.json'}")
        return

    from extract import Extractor  # noqa: E402  (needs mlx)

    model = args.model or cfg.get("model")
    rows = read_jsonl(data_file)
    if args.limit:
        rows = rows[: args.limit]
    if args.out:
        out = Path(args.out)
    elif args.adapter_path:
        out = Path(args.adapter_path) / "eval"
    else:
        out = Path("runs") / f"eval-{time.strftime('%Y%m%d-%H%M%S')}"
    out.mkdir(parents=True, exist_ok=True)

    print(f"evaluating {model}" + (f" + {args.adapter_path}" if args.adapter_path else " (no adapter)") +
          f" on {len(rows)} rows from {data_file}")
    ex = Extractor(model, args.adapter_path, str(schema_path), args.max_tokens, args.batch_size, verbose=True)
    t0 = time.time()
    results = ex.extract_many([r["raw_message"] for r in rows])
    dt = time.time() - t0
    print(f"generation: {dt:.0f}s total, {dt / len(rows):.2f}s per message")

    pred_rows = []
    for r, res in zip(rows, results):
        pred_rows.append({
            "idx": r.get("idx"), "source": r.get("source", "unknown"), "group": r.get("group"),
            "raw_message": r["raw_message"], "labels": r["labels"],
            "quotes": res["quotes"], "ok": res["ok"], "error": res["error"],
            "warnings": res["warnings"], "raw_output": res["raw_output"],
        })
    report, scored = score_predictions(pred_rows, keys, literal_fields)
    report["run"] = {"model": model, "adapter_path": args.adapter_path, "data": str(data_file),
                     "n": len(rows), "seconds": round(dt, 1), "seconds_per_message": round(dt / len(rows), 3),
                     "when": time.strftime("%Y-%m-%d %H:%M:%S")}
    for pr, s in zip(pred_rows, scored):
        pr["exact"] = s["exact"]
        pr["field_errors"] = {k: {m: v for m, v in f.items() if m in ("missed", "spurious", "wrong") and v}
                              for k, f in s["fields"].items() if (f["missed"] or f["spurious"] or f["wrong"])}
    write_jsonl(out / "predictions.jsonl", pred_rows)
    write_jsonl(out / "errors.jsonl", [r for r in pred_rows if not r["exact"]])
    (out / "metrics.json").write_text(json.dumps(report, indent=2))
    print_report(report, keys)
    print(f"\npredictions -> {out / 'predictions.jsonl'}   errors -> {out / 'errors.jsonl'}   metrics -> {out / 'metrics.json'}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Inference: Bloomberg chat line(s) -> list of quote objects.

    # with an adapter on the base model
    python extract.py --model mlx-community/gemma-4-e4b-it-bf16 --adapter-path adapters/run-... \
        "13:04:52 IAN BUEHLER: GC 3mo FF+43.1 / FF+50.4"

    # with a fused model (fuse.sh copies schema.json in as bbchat_schema.json)
    python extract.py --model models/bbchat-e4b "13:04:52 IAN BUEHLER: GC 3mo FF+43.1 / FF+50.4"

    # a file of raw lines (one message per line) -> JSONL
    python extract.py --model models/bbchat-e4b --input chat_dump.txt --out parsed.jsonl

Greedy decoding, thinking disabled, output validated against the schema. The
`Extractor` class is what evaluate.py uses, so inference and evaluation share
one code path.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (  # noqa: E402
    canonical_labels,
    disable_thinking,
    is_grounded,
    load_schema,
    make_messages,
    parse_output,
)


class Extractor:
    def __init__(self, model: str, adapter_path: str | None = None, schema: str | None = None,
                 max_tokens: int = 384, batch_size: int = 8, verbose: bool = False):
        from mlx_lm import load

        if schema is None:
            for cand in (Path(model) / "bbchat_schema.json", Path("data/schema.json")):
                if cand.exists():
                    schema = str(cand)
                    break
        if schema is None:
            raise FileNotFoundError("no schema.json found; pass --schema data/schema.json")
        self.schema = load_schema(schema)
        self.keys: list[str] = self.schema["keys"]
        self.system_prompt: str = self.schema["system_prompt"]
        self.literal_fields: list[str] = self.schema.get("literal_fields", [])
        self.max_tokens = max_tokens
        self.batch_size = max(1, batch_size)
        self.verbose = verbose

        t0 = time.time()
        self.model, self.tokenizer = load(model, adapter_path=adapter_path)
        disable_thinking(self.tokenizer)
        self.model_id = model
        self.adapter_path = adapter_path
        if verbose:
            print(f"[extractor] loaded {model}" + (f" + {adapter_path}" if adapter_path else "") +
                  f" in {time.time() - t0:.1f}s", file=sys.stderr)

    # -- prompt -------------------------------------------------------------------
    def prompt_ids(self, raw_message: str) -> list[int]:
        text = self.tokenizer.apply_chat_template(
            make_messages(self.system_prompt, raw_message),
            add_generation_prompt=True, tokenize=False,
        )
        # the rendered text already starts with <bos>; do not add a second one
        return self.tokenizer.encode(text, add_special_tokens=False)

    # -- generation ---------------------------------------------------------------
    def generate_texts(self, raw_messages: list[str]) -> list[str]:
        from mlx_lm import batch_generate, generate
        from mlx_lm.sample_utils import make_sampler

        sampler = make_sampler(temp=0.0)  # greedy
        prompts = [self.prompt_ids(m) for m in raw_messages]
        if self.batch_size == 1 or len(prompts) == 1:
            return [generate(self.model, self.tokenizer, prompt=p, max_tokens=self.max_tokens,
                             sampler=sampler, verbose=False) for p in prompts]
        texts: list[str] = []
        for i in range(0, len(prompts), self.batch_size):
            chunk = prompts[i:i + self.batch_size]
            resp = batch_generate(self.model, self.tokenizer, chunk, max_tokens=self.max_tokens,
                                  sampler=sampler, verbose=False)
            texts.extend(resp.texts)
            if self.verbose:
                print(f"[extractor] {min(i + self.batch_size, len(prompts))}/{len(prompts)}", file=sys.stderr)
        return texts

    # -- parsing / validation -----------------------------------------------------
    def postprocess(self, raw_message: str, text: str) -> dict:
        quotes, err = parse_output(text)
        result = {"raw_message": raw_message, "ok": err is None, "error": err,
                  "quotes": None, "raw_output": text, "warnings": []}
        if quotes is None and err in ("text before JSON", "text after JSON"):
            quotes, err2 = parse_output(text, lenient=True)
            if quotes is not None:
                # usable, but the model did not emit *only* the array; evaluate.py counts this as not "clean"
                result.update(ok=True, error=None)
                result["warnings"].append(f"salvaged JSON: {err}")
        if quotes is None:
            return result
        try:
            quotes = canonical_labels(quotes, self.keys)
        except TypeError as e:
            result.update(ok=False, error=str(e))
            return result
        for i, q in enumerate(quotes):
            for k in self.literal_fields:
                v = q.get(k)
                if v is not None and not is_grounded(v, raw_message):
                    result["warnings"].append(f"leg {i}: {k}={v!r} not found verbatim in message")
        result["quotes"] = quotes
        return result

    def extract_many(self, raw_messages: list[str]) -> list[dict]:
        texts = self.generate_texts(raw_messages)
        return [self.postprocess(m, t) for m, t in zip(raw_messages, texts)]

    def extract(self, raw_message: str) -> dict:
        return self.extract_many([raw_message])[0]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("messages", nargs="*", help="raw chat message(s)")
    p.add_argument("--model", required=True, help="fused model dir, or base model (then pass --adapter-path)")
    p.add_argument("--adapter-path", default=None)
    p.add_argument("--schema", default=None, help="schema.json (default: <model>/bbchat_schema.json or data/schema.json)")
    p.add_argument("--input", default=None, help="text file with one raw message per line, or JSONL with raw_message")
    p.add_argument("--out", default=None, help="write JSONL results here (default: stdout)")
    p.add_argument("--max-tokens", type=int, default=384)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--quiet", action="store_true")
    args = p.parse_args()

    msgs = list(args.messages)
    if args.input:
        text = Path(args.input).read_text(encoding="utf-8")
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith("{"):
                try:
                    line = json.loads(line).get("raw_message", line)
                except json.JSONDecodeError:
                    pass
            msgs.append(line)
    if not msgs:
        sys.exit("nothing to extract: pass messages or --input")

    ex = Extractor(args.model, args.adapter_path, args.schema, args.max_tokens, args.batch_size,
                   verbose=not args.quiet)
    t0 = time.time()
    results = ex.extract_many(msgs)
    dt = time.time() - t0
    out = open(args.out, "w", encoding="utf-8") if args.out else sys.stdout
    for r in results:
        out.write(json.dumps(r, ensure_ascii=False) + "\n")
    if args.out:
        out.close()
    n_ok = sum(r["ok"] for r in results)
    print(f"[extractor] {len(results)} messages in {dt:.1f}s ({dt / len(results):.2f}s each); "
          f"{n_ok} parsed, {len(results) - n_ok} failed, "
          f"{sum(bool(r['warnings']) for r in results)} with grounding warnings", file=sys.stderr)


if __name__ == "__main__":
    main()

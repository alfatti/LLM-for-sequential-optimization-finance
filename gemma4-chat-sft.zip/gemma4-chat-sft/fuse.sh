#!/usr/bin/env bash
# Merge a trained adapter into the base weights and (optionally) quantize the result for serving.
#
#   ./fuse.sh adapters/run-20261029-0130                 # -> models/bbchat-e4b (bf16, or the base's quant if QLoRA)
#   QUANT=8 ./fuse.sh adapters/run-20261029-0130          # also writes models/bbchat-e4b-8bit
#   OUT=models/bbchat-v2 ./fuse.sh adapters/run-...
#
# The fused directory is a normal mlx-lm model: `mlx_lm.generate --model models/bbchat-e4b ...`,
# `mlx_lm.server --model models/bbchat-e4b` (OpenAI-compatible HTTP), or extract.py.
# GGUF export via mlx_lm.fuse is not available for the gemma4 architecture; use llama.cpp's
# converter on the fused HF-format weights if you need GGUF.
set -euo pipefail
cd "$(dirname "$0")"

ADAPTER=${1:?usage: ./fuse.sh <adapter-dir>}
OUT=${OUT:-models/bbchat-e4b}
SCHEMA=${SCHEMA:-data/schema.json}
MODEL=${MODEL:-$(python -c "import json,sys; print(json.load(open('$ADAPTER/adapter_config.json'))['model'])")}

echo "==> fusing $ADAPTER into $MODEL -> $OUT"
mlx_lm.fuse --model "$MODEL" --adapter-path "$ADAPTER" --save-path "$OUT"
[[ -f "$SCHEMA" ]] && cp -f "$SCHEMA" "$OUT/bbchat_schema.json"

if [[ -n "${QUANT:-}" ]]; then
  echo "==> quantizing fused model to ${QUANT}-bit -> ${OUT}-${QUANT}bit"
  mlx_lm.convert --hf-path "$OUT" -q --q-bits "$QUANT" --mlx-path "${OUT}-${QUANT}bit"
  [[ -f "$SCHEMA" ]] && cp -f "$SCHEMA" "${OUT}-${QUANT}bit/bbchat_schema.json"
fi

echo
echo "==> smoke test"
python extract.py --model "$OUT" "13:04:52 IAN BUEHLER: GC 3mo FF+43.1 / FF+50.4"

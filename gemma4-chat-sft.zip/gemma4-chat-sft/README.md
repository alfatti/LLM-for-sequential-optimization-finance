# Gemma 4 E4B · SFT pipeline for Bloomberg-chat quote extraction (Apple Silicon / MLX)

Supervised fine-tuning of `google/gemma-4-E4B-it` with LoRA via `mlx-lm`, on the labelled
sample (`raw_message` → `labels[]`), producing a literal extractor that emits a JSON array
of quote objects with a fixed key order.

```
labels.json ──prepare_data.py──▶ data/{train,valid,test}.jsonl + schema.json
                                      │
                       check_setup.py (template / mask / lengths / LoRA keys)
                                      │
                               train.sh ──▶ adapters/run-<stamp>/adapters.safetensors
                                      │
                 evaluate.py (field-level metrics, per source)   extract.py (inference)
                                      │
                               fuse.sh ──▶ models/bbchat-e4b[ -8bit ]
```

## Files

| file | what it does |
|---|---|
| `USER_GUIDE.txt` | plain-language, step-by-step instructions (start here) |
| `common.py` | schema, canonical JSON target, system prompt, output parsing, value comparison, grounding checks, `disable_thinking` |
| `prepare_data.py` | labels → mlx-lm chat JSONL; dedupe; template-group split stratified by `source`; stats; label QA |
| `check_setup.py` | pre-flight: renders an example the way mlx-lm will, verifies the prompt mask aligns, exact token lengths, LoRA keys |
| `configs/lora_e4b.yaml` | LoRA hyper-parameters (commented) |
| `resolve_config.py` | fills iters / schedule / eval cadence from EPOCHS and the data; run record |
| `train.py` | `mlx_lm.lora` with thinking disabled in the chat template |
| `train.sh` | launcher (`EPOCHS`, `MODEL`, `BATCH`, `NUM_LAYERS`, `SMOKE=1`, `RESUME=`) |
| `evaluate.py` | greedy generation on a split + exact-match / per-field / grounding metrics; `--score-only` re-scores a predictions file |
| `extract.py` | `Extractor` class + CLI: message(s) or a file → JSONL |
| `fuse.sh` | merge adapter into the base; optional 8/4-bit quantization; smoke test |

## Setup

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
hf auth login            # only needed for google/gemma-4-E4B-it (gated); mlx-community mirrors are open
```

Pick the base by unified memory (set in `configs/lora_e4b.yaml` or via `MODEL=`):

| memory | model | notes |
|---|---|---|
| 32 GB+ | `mlx-community/gemma-4-e4b-it-bf16` (default) or `google/gemma-4-E4B-it` | bf16 LoRA; weights ~16 GB, training peak ~20-25 GB |
| 24 GB | `models/gemma-4-e4b-it-8bit` | QLoRA on an 8-bit base, peak ~12-15 GB |
| 16 GB | `models/gemma-4-e4b-it-4bit` | QLoRA on a 4-bit base, peak ~8-10 GB; small quality cost |

Build a quantized base once:
```bash
mlx_lm.convert --hf-path google/gemma-4-E4B-it -q --q-bits 8 --mlx-path models/gemma-4-e4b-it-8bit
```
mlx-lm loads only the text decoder of the multimodal checkpoint; the vision/audio towers are dropped.
If memory is still tight: `BATCH=2`, `NUM_LAYERS=21`, keep `grad_checkpoint: true`.

## Run order

```bash
# 1. data: labels.json is your file (JSON array or JSONL of {raw_message, labels[], source})
python prepare_data.py --input labels.json --out data
#    read the printed table: non-null rate and "literal" rate per field, duplicates, label_qa.jsonl

# 2. pre-flight (seconds; add --load-model to also load the weights and verify LoRA keys)
python check_setup.py
python check_setup.py --load-model

# 3. 8-iteration smoke run: model loads, memory fits, you see the real tok/s
SMOKE=1 ./train.sh

# 4. the run (2 epochs by default; watch val loss in the log, checkpoints every epoch)
EPOCHS=2 ./train.sh
#    -> adapters/run-<stamp>/{adapters.safetensors, config.resolved.yaml, run_summary.json, train.log}

# 5. evaluate on the held-out test split (and the untuned model as a baseline)
python evaluate.py --adapter-path adapters/run-<stamp>
python evaluate.py --out runs/baseline                 # no adapter, same prompt
#    -> metrics.json, predictions.jsonl, errors.jsonl under the adapter dir

# 6. fuse for serving (+ optional quantization)
QUANT=8 ./fuse.sh adapters/run-<stamp>                 # -> models/bbchat-e4b, models/bbchat-e4b-8bit

# 7. use it
python extract.py --model models/bbchat-e4b "13:04:52 IAN BUEHLER: GC 3mo FF+43.1 / FF+50.4"
python extract.py --model models/bbchat-e4b --input chat_dump.txt --out parsed.jsonl
mlx_lm.server --model models/bbchat-e4b --chat-template-args '{"enable_thinking":false}'
```

Resume an interrupted run: `RESUME=adapters/run-<stamp>/adapters.safetensors ./train.sh`.
Compare runs: every adapter dir carries its resolved config and `eval/metrics.json`.

## What the pipeline fixes in place

* **Target format.** Always a JSON array (multi-leg ready), every key present in schema order,
  nulls explicit, compact separators, numbers as numbers. Deterministic → trivially parseable,
  and the fixed key order means the model never has to decide *what* to emit, only the values.
* **Loss on the answer only** (`mask_prompt: true`). The JSON is ~50% of each sequence; without
  masking, half the gradient would go to reproducing the broker's message.
* **Thinking off, consistently.** Gemma 4 IT has a thought channel; mlx-lm's tokenizer wrapper
  turns `enable_thinking` *on* by default when it sees those tokens, including inside the LoRA
  data loader. `train.py`, `check_setup.py`, `evaluate.py` and `extract.py` all force it off so
  training, evaluation and serving see the same prompt. `check_setup.py` prints the rendered
  example so you can see there is no `<|think|>` in it.
* **Prompt-mask alignment.** `check_setup.py` verifies the generation prompt is a strict prefix
  of the full render. If a template variant adds an empty-thought prefill to the generation
  prompt only, re-run `prepare_data.py --assistant-prefix '<|channel>thought\n<channel|>'`.
* **No leakage across splits.** Exact duplicates are dropped; the split is by template signature
  (label values and numbers masked) stratified by `source`, so synthetic variants of one template
  cannot sit in both train and test. If a source has fewer than `--min-groups` templates it falls
  back to a random split and says so.
* **A literal-extractor audit.** For each field, `prepare_data.py` measures how often the gold
  value appears verbatim in the message. Fields ≥95% are "literal"; `evaluate.py` and
  `extract.py` then flag any predicted value for those fields that is *not* in the message
  (hallucination detector). Gold values that fail the check land in `label_qa.jsonl`.

## Hyper-parameters (configs/lora_e4b.yaml)

LoRA rank 16, scale 20 (mlx-lm's scale ≈ PEFT alpha/rank), dropout 0.05, on q/k/v/o and
gate/up/down of all 42 blocks; AdamW, peak lr 1e-5 (≈ PEFT 1e-4 at alpha/r = 2), 5% warmup,
cosine to lr/10; batch 4 × accumulation 2; `max_seq_length 512`; 2 epochs.
Change `rank`, `learning_rate`, `num_layers` in the YAML; `EPOCHS`, `BATCH`, `NUM_LAYERS`, `LR`,
`MAX_SEQ` as env vars override per run.

## Reading the evaluation

`exact` is the number that matters (whole message correct, strict types). Then the per-field
table: `recall` on gold non-null values catches "always null" collapse on sparse fields
(TRADE, SIZE, QUOTE_INTENT); `spurious` catches invented values; `wrong` catches digit errors;
`ground` (literal fields only) catches values not copied from the message. Look at `errors.jsonl`
before touching hyper-parameters — most early failures are label inconsistencies.

## Known limits

* `evaluate.py` / `extract.py` use `mlx_lm.batch_generate`; if your mlx-lm version refuses batched
  generation for this architecture, pass `--batch-size 1` (sequential `generate`).

* `mlx_lm.fuse --export-gguf` does not support the gemma4 architecture; use llama.cpp's converter
  on the fused weights if you need GGUF.
* mlx-lm batches training examples by sorting on length; a trailing partial batch is dropped
  each epoch (`resolve_config.py` accounts for it).
* Grounding checks are string-level; a value like `5k` → `5000` is a normalisation, not a
  literal copy, and the field will not be marked literal (check `field_literal_rate`).

#!/usr/bin/env python3
"""
`mlx_lm.lora` with one change: the chat template is rendered with thinking
disabled (see common.disable_thinking). Everything else, flags included, is
mlx-lm's own trainer, so `python train.py --config ... [any mlx_lm.lora flag]`.

train.sh calls this; you normally do not run it by hand.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import disable_thinking  # noqa: E402

from mlx_lm import lora as mlx_lora  # noqa: E402

_orig_load = mlx_lora.load


def _load_no_think(*args, **kwargs):
    out = _orig_load(*args, **kwargs)
    disable_thinking(out[1])  # (model, tokenizer[, config])
    return out


mlx_lora.load = _load_no_think

if __name__ == "__main__":
    mlx_lora.main()
